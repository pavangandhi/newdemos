package com.fruitjewel.entity;

public interface ISprite {
  
  public int getRow();//
  
  public int getCol();//
  
  public void setMapPosition(final int row, final int col);//
  
}