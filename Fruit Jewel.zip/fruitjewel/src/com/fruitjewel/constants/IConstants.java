package com.fruitjewel.constants;

/**
 * @author Qingfeng
 * @time 2010-11-03
 */
public interface IConstants {
	// ===========================================================
	  // Final Fields
	  // ===========================================================
	 //private static final int CAMERA_WIDTH = 320; 
	 // private static final int CAMERA_HEIGHT = 480; 
	  
	  /****/
	  //public static  int CELLS_HORIZONTAL = 8;
	  //public static  int CELLS_VERTICAL = 8;
	  
	  /****/
	  //public static int CELL_WIDTH = 40;
	  //public static int CELL_HEIGHT = CELL_WIDTH;  
	  
	  /****/
	  //public  final int CELLBG_HORIZONTAL = 4;
	  //public  final int CELLBG_VERTICAL = CELLBG_HORIZONTAL;  
	  
	  /****/
	  //public static  int CELLBG_WIDTH = 80;
	  //public static  int CELLBG_HEIGHT = CELLBG_WIDTH;
	  
	  /****/
	  final int STATE_NORMAL = 0;  //
	  final int STATE_SCALEINT = STATE_NORMAL + 1; //1
	  final int STATE_FALL = STATE_SCALEINT + 1;   //2
	//  final int STATE_FALL_FINISH = STATE_FALL + 1;//
	  final int STATE_DEAD = STATE_FALL + 1;//3

	  // ===========================================================
	  // Methods
	  // ===========================================================
	}